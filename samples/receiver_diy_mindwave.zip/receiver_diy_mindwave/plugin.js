import SerialPort from 'serialport';
import _ from 'lodash';

export default class TcpSender {
  constructor(eegController) {
    this.eegController = eegController;
    this.data = '';
  }

  start({ com_port }) {
    console.log('Starting at', com_port);
    return new Promise((resolve, reject) => {
      this.serial = new SerialPort(com_port, {
        baudRate: 57600,
        parser: new SerialPort.parsers.Readline('\n'),
      });

      const parser = this.serial.pipe(new SerialPort.parsers.Delimiter({ delimiter: Buffer.from('\n') }));

      this.serial.on('open', () => {
        console.log('Starting at', 'success');
        resolve();
        parser.on('data', (data) => {
          const values = String(data).split(',');

          const attention = parseInt(values[1], 10);
          const meditation = parseInt(values[2], 10);

          const delta = parseInt(values[3], 10);
          const theta = parseInt(values[4], 10);
          const lowAlpha = parseInt(values[5], 10);
          const highAlpha = parseInt(values[6], 10);
          const lowBeta = parseInt(values[7], 10);
          const highBeta = parseInt(values[8], 10);
          const lowGamma = parseInt(values[9], 10);
          const highGamma = parseInt(values[10], 10);

          this.eegController
            .reset()
            .on('fp1', {
              delta, theta, lowAlpha, highAlpha, lowBeta, highBeta, lowGamma, highGamma,
            })
            .with({
              meditation, attention,
            })
            .flush();
        });
      });
    });
  }

  stop() {
    return new Promise((resolve, reject) => {
      this.serial.close();
      resolve();
    });
  }
}
